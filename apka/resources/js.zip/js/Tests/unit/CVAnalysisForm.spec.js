import { shallowMount } from '@vue/test-utils';
import CVAnalysisForm from '@/components/CVAnalysisForm.vue';

describe('CVAnalysisForm.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(CVAnalysisForm);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when a CV is analyzed', async () => {
    const wrapper = shallowMount(CVAnalysisForm);
    const analyzeButton = wrapper.find('.analyze-button'); 
    
    await analyzeButton.trigger('click');

    expect(wrapper.emitted().cvAnalyzed).toBeTruthy();
  });
});
