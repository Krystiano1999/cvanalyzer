import { shallowMount } from '@vue/test-utils';
import JobPostModalAdd from '@/components/JobPostModalAdd.vue';

describe('JobPostModalAdd.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(JobPostModalAdd);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when a job post is added', async () => {
    const wrapper = shallowMount(JobPostModalAdd);
    const addButton = wrapper.find('.add-button'); 
    await addButton.trigger('click');
    expect(wrapper.emitted().jobPostAdded).toBeTruthy();
  });
});
