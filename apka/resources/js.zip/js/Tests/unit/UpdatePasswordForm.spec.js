import { shallowMount } from '@vue/test-utils';
import UpdatePasswordForm from '@/components/UpdatePasswordForm.vue';

describe('UpdatePasswordForm.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(UpdatePasswordForm);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when the password is updated', async () => {
    const wrapper = shallowMount(UpdatePasswordForm);
    const updateButton = wrapper.find('.update-button'); 

    await updateButton.trigger('click');

    expect(wrapper.emitted().passwordUpdated).toBeTruthy();
  });
});
