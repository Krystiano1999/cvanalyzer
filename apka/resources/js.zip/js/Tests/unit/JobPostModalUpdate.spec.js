import { shallowMount } from '@vue/test-utils';
import JobPostModalUpdate from '@/components/JobPostModalUpdate.vue';

describe('JobPostModalUpdate.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(JobPostModalUpdate);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when a job post is updated', async () => {
    const wrapper = shallowMount(JobPostModalUpdate);
    const updateButton = wrapper.find('.update-button'); 

    await updateButton.trigger('click');

    expect(wrapper.emitted().jobPostUpdated).toBeTruthy();
  });
});
