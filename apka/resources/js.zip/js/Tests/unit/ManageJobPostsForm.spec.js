import { shallowMount } from '@vue/test-utils';
import ManageJobPostsForm from '@/components/ManageJobPostsForm.vue';

describe('ManageJobPostsForm.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(ManageJobPostsForm);
    expect(wrapper.exists()).toBe(true);
  });

  it('calls method to manage job posts when form is submitted', async () => {
    const wrapper = shallowMount(ManageJobPostsForm);
    const form = wrapper.find('form');

    await form.trigger('submit.prevent');

    expect(wrapper.emitted().manageJobPosts).toBeTruthy();
  });
});
