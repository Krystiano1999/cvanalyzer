import { shallowMount } from '@vue/test-utils';
import ViewApplicationsForm from '@/components/ViewApplicationsForm.vue';

describe('ViewApplicationsForm.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(ViewApplicationsForm);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when an application is viewed', async () => {
    const wrapper = shallowMount(ViewApplicationsForm);
    const viewButton = wrapper.find('.view-button'); 

    await viewButton.trigger('click');

    expect(wrapper.emitted().applicationViewed).toBeTruthy();
  });
});
