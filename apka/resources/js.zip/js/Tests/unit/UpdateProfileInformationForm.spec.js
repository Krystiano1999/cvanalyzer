import { shallowMount } from '@vue/test-utils';
import UpdateProfileInformationForm from '@/components/UpdateProfileInformationForm.vue';

describe('UpdateProfileInformationForm.vue', () => {
  it('renders component correctly', () => {
    const wrapper = shallowMount(UpdateProfileInformationForm);
    expect(wrapper.exists()).toBe(true);
  });

  it('emits an event when the profile information is updated', async () => {
    const wrapper = shallowMount(UpdateProfileInformationForm);
    const updateButton = wrapper.find('.update-button'); 

    await updateButton.trigger('click');

    expect(wrapper.emitted().profileUpdated).toBeTruthy();
  });
});
