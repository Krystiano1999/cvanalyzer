<template>
  <div class="flex items-center justify-center font-semibold">
    <span class="text-gray-500">P</span>
    <span class="text-gray-600">a</span>
    <span class="text-gray-600">n</span>
    <span class="text-gray-700">e</span>
    <span class="text-gray-700">l</span>
    <span class=""> </span> 
    <span class="text-pink-800">C</span>
    <span class="text-pink-700">V</span>
    <span class=""> </span> 
    <span class="text-cyan-600">A</span>
    <span class="text-cyan-600">n</span>
    <span class="text-cyan-600">a</span>
    <span class="text-cyan-600">l</span>
    <span class="text-cyan-600">y</span>
    <span class="text-cyan-700">z</span>
    <span class="text-cyan-700">e</span>
    <span class="text-cyan-700">r</span>
  </div>
</template>

<script setup>
    import {Link} from '@inertiajs/vue3';
</script>